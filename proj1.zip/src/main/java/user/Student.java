package user;

public class Student{
    private String StudentID;
    private String StudentPassword;
    private String StudentLecturer;
    private String StudentName;
    private String StudentGender;
    private String StudentMajor;
    private String StudentYear;
    private String StudentState;
    private String StudentClassID;
    public String getStudentID() {
        return StudentID;
    }

    public void setStudentID(String StudentID) {
        this.StudentID = StudentID;
    }

    public String getStudentPassword() {
        return StudentPassword;
    }

    public void setStudentPassword(String StudentPassword) {
        this.StudentPassword = StudentPassword;
    }

    public String getStudentName() {
        return StudentName;
    }

    public void setStudentName(String StudentName) {
        this.StudentName = StudentName;
    }

    public String getStudentGender() {
        return StudentGender;
    }

    public void setStudentGender(String StudentGender) {
        this.StudentGender = StudentGender;
    }

    public String getStudentLecturer() {
        return StudentLecturer;
    }

    public void setStudentLecturer(String StudentLecturer) {this.StudentLecturer = StudentLecturer;}

    public String getStudentMajor() {
        return StudentMajor;
    }

    public void setStudentMajor(String StudentMajor) {this.StudentMajor = StudentMajor;}

    public String getStudentYear() { return StudentYear; }

    public void setStudentYear(String StudentYear) {this.StudentYear = StudentYear;}


    public String getStudentState() {
        return StudentState;
    }

    public void setStudentState(String studentState) {
        StudentState = studentState;
    }

    public String getStudentClassID() {
        return StudentClassID;
    }

    public void setStudentClassID(String studentClassID) {
        StudentClassID = studentClassID;
    }
}

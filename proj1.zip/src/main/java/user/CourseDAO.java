package user;

import java.sql.*;
import java.util.ArrayList;

public class CourseDAO {


    private Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs;

    public CourseDAO()
    {
        try{
            //3306뒤에 bbs는 DB의 이름
            String dbURL = "jdbc:mysql://localhost:3306/db2018008204?serverTimezone=Asia/Seoul";
            String dbID = "root";
            String dbPassword = "sdijmkn7907";
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public int timeConvert(String time)
    {
        int weekday = Integer.parseInt(time.substring(9,10));
        int hour = Integer.parseInt(time.substring(11,13));
        int minute = Integer.parseInt(time.substring(14,16));
        return ((weekday-1)*24*60 + hour*60 + minute);
    }

    public String timeInput(String weekday, String hour, String minute)
    {
        String timeForm = "1900-01-0";
        if(Integer.parseInt(hour)>23
        || Integer.parseInt(hour)<1
        && Integer.parseInt(minute)!=00
        || Integer.parseInt(minute)!=30)
            return "";
        if(weekday.equals("월"))
            timeForm += "1T"+hour+":"+minute+":00.000Z";
        else if(weekday.equals("화"))
            timeForm += "2T"+hour+":"+minute+":00.000Z";
        else if(weekday.equals("수"))
            timeForm += "3T"+hour+":"+minute+":00.000Z";
        else if(weekday.equals("목"))
            timeForm += "4T"+hour+":"+minute+":00.000Z";
        else if(weekday.equals("금"))
            timeForm += "5T"+hour+":"+minute+":00.000Z";
        else if(weekday.equals("토"))
            timeForm += "6T"+hour+":"+minute+":00.000Z";
        else return "";
        return timeForm;
    }

    public String timeShow(String time)
    {
        String timeForm = "";

        int weekday = Integer.parseInt(time.substring(9,10));
        String hour = time.substring(11,13);
        String minute = time.substring(14,16);
        if(weekday==1)
            timeForm = "월 "+hour+":"+minute;
        else if(weekday==2)
            timeForm = "화 "+hour+":"+minute;
        else if(weekday==3)
            timeForm = "수 "+hour+":"+minute;
        else if(weekday==4)
            timeForm = "목 "+hour+":"+minute;
        else if(weekday==5)
            timeForm = "금 "+hour+":"+minute;
        else if(weekday==6)
            timeForm = "토 "+hour+":"+minute;
        return timeForm;
    }
    //설강
    public int createClass(Course course)
    {
        int result;

        //해당 교강사 존재하는 지 확인
        String lecturer_id = null;
            String SQL1 = "SELECT lecturer_id FROM lecturer WHERE name = ?";
        try{
            pstmt =conn.prepareStatement(SQL1);
            pstmt.setString(1,course.getClassLecturer());
            rs = pstmt.executeQuery();
            if(rs.next()){
                lecturer_id = rs.getString(1);
            }
            else{
                return -2; //해당 이름의 교강사가 존재하지 않음
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        //강의실 수용인원과 수강 정원 비교
        int occupancy = 100001;
        String SQL2 = "SELECT occupancy FROM room WHERE room_id = ?";
        try{
            pstmt =conn.prepareStatement(SQL2);
            pstmt.setString(1,course.getClassRoomID());
            rs = pstmt.executeQuery();
            if(rs.next())
                occupancy= Integer.parseInt(rs.getString(1));
            if (Integer.parseInt(course.getClassPersonMax()) > occupancy){
                return -3; //강의실 수용인원보다 수강 정원이 더 많음
            }
            if(occupancy==100001)
                return -6; //강의실 존재하지 않음
        } catch (Exception e) {
            e.printStackTrace();
        }


        //전공번호 존재하는 지 확인
        String SQL3 = "SELECT * FROM major WHERE major_id = ?";
        try{
            pstmt =conn.prepareStatement(SQL3);
            pstmt.setString(1,course.getClassMajorID());
            rs = pstmt.executeQuery();
            if (!rs.next())
                return -4; //해당 번호의 전공이 존재하지 않습니다.
        } catch (Exception e) {
            e.printStackTrace();
        }

        //학수번호(course_id) 존재하는 지 확인
        String courseName = "";
        String SQL4 = "SELECT name FROM course WHERE course_id = ?";
        try{
            pstmt =conn.prepareStatement(SQL4);
            pstmt.setString(1,course.getClassCourseNo());
            rs = pstmt.executeQuery();
            if (rs.next())
                courseName = rs.getString(1);
            if (courseName.equals(""))
                return -5; //해당 번호의 과목이 존재하지 않습니다.
        } catch (Exception e) {
            e.printStackTrace();
        }

        //수업 시간 형태 체크
        if(course.getClassStartTime().length()!=6
        ||course.getClassEndTime().length()!=6)
            return -7; //날짜 형식에 안 맞음
        String weekdayBegin = course.getClassStartTime().substring(0,1);
        String weekdayEnd = course.getClassEndTime().substring(0,1);
        String hourBegin = course.getClassStartTime().substring(1,3);
        String hourEnd = course.getClassEndTime().substring(1,3);
        String minuteBegin = course.getClassStartTime().substring(4,6);
        String minuteEnd = course.getClassEndTime().substring(4,6);
        String inputBegin = timeInput(weekdayBegin,hourBegin,minuteBegin);
        String inputEnd = timeInput(weekdayEnd,hourEnd,minuteEnd);
        if(weekdayBegin.equals("일")
        || weekdayEnd.equals("일"))
            return -8; //일요일 강의 개설 불가
        if(inputBegin.equals("") || inputEnd.equals(""))
            return -7; //날짜 형식에 안 맞음

        String SQL5 = "INSERT INTO class(class_no,course_id,name," +
                "major_id, year,credit ,lecturer_id,person_max,opened,room_id,person_current)" +
                "VALUES (?, ?, ?, ?,?,?,?, ?,2022,?,0)";
        try{

            pstmt = conn.prepareStatement(SQL5);
            pstmt.setString(1,course.getClassNo());
            pstmt.setString(2,course.getClassCourseNo());
            pstmt.setString(3,courseName);
            pstmt.setString(4,course.getClassMajorID());
            pstmt.setString(5,course.getClassYear());
            pstmt.setString(6,course.getClassCredit());
            pstmt.setString(7,lecturer_id);
            pstmt.setString(8,course.getClassPersonMax());
            pstmt.setString(9,course.getClassRoomID());
            result = pstmt.executeUpdate();

            if(result == 0)
                return -1; //insert 실패
        } catch (Exception e) {
            e.printStackTrace();
        }

        //새로 추가된 수업 class_id
        String class_id ="";
        String SQL6 = "SELECT class_id FROM class order by class_id DESC limit 1";
        try{
            pstmt =conn.prepareStatement(SQL6);
            rs = pstmt.executeQuery();
            if (rs.next())
                class_id = rs.getString(1);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //time table에 해당 수업 추가
        String SQL7 = "INSERT INTO time(class_id,period,begin,end) VALUES (?,1,?,?);";
        try{
            pstmt =conn.prepareStatement(SQL7);
            pstmt.setString(1,class_id);
            pstmt.setString(2,inputBegin);
            pstmt.setString(3,inputEnd);
            result = pstmt.executeUpdate();
            if (result==0)
                return -1; //수업 insert 실패
            return 1;
        } catch (Exception e) {
            e.printStackTrace();
        }


        return -1; // 데이터베이스 오류
    }

    //폐강
    public int deleteClass(Course course)
    {
        int result;
        String SQL = "SELECT * FROM class WHERE class_id = ?";
        try{
            pstmt =conn.prepareStatement(SQL);
            pstmt.setString(1,course.getClassID());
            rs = pstmt.executeQuery();
            if(!rs.next()){
                return -1; //해당 id의 수업이 존재하지 않음
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String SQL2 ="DELETE FROM class WHERE class_id =?";
        try{
            pstmt = conn.prepareStatement(SQL2);
            pstmt.setString(1,course.getClassID());
            result = pstmt.executeUpdate();
            if(result == 0)
            {
                return -2; //delete 실패
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String SQL3 ="DELETE FROM regist WHERE class_id =?";
        try{
            pstmt = conn.prepareStatement(SQL3);
            pstmt.setString(1,course.getClassID());
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

        String SQL4 ="DELETE FROM hope WHERE class_id =?";
        try{
            pstmt = conn.prepareStatement(SQL4);
            pstmt.setString(1,course.getClassID());
            pstmt.executeUpdate();
            return 1; //insert 성공
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -2; // 데이터베이스 오류
    }

    // 과목 증원
    public int increaseClass(Course course)
    {
        int result;
        int occupancy;
        int cur_person_max = 0;

        String SQL1 = "SELECT person_max, occupancy FROM class NATURAL JOIN room WHERE class_id = ? ";
        try{
            pstmt =conn.prepareStatement(SQL1);
            pstmt.setString(1,course.getClassID());
            rs = pstmt.executeQuery();
            if(!rs.next()){
                return -1; //해당 id의 수업이 존재하지 않음
            }
            else{
                cur_person_max = rs.getInt(1);
                occupancy = rs.getInt(2);
                if (cur_person_max+Integer.parseInt(course.getClassPersonMax()) > occupancy)
                    return -2; //해당 수업 증원인원이 강의실 수용인원을 초과함
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String SQL2 ="UPDATE class SET person_max =? WHERE class_id =?";
        try{
            pstmt = conn.prepareStatement(SQL2);
            pstmt.setInt(1,cur_person_max+Integer.parseInt(course.getClassPersonMax()));
            pstmt.setString(2,course.getClassID());
            result = pstmt.executeUpdate();
            if(result == 0)
                return -3; //update 실패
            return 1; //update 성공
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -4; // 데이터베이스 오류
    }

    //   수강편람
    public ArrayList<Course> showAll(int choose, String searchWord)
    {
        String SQL = "SELECT class.class_id, class_no,course_id,class.name,lecturer.name,begin,end,person_current,person_max,room.room_id,building.name\n" +
                    "FROM class\n" +
                    "JOIN time\n" +
                    "ON class.class_id = time.class_id\n" +
                    "JOIN lecturer\n" +
                    "ON lecturer.lecturer_id = class.lecturer_id\n" +
                    "JOIN room\n" +
                    "ON room.room_id = class.room_id\n" +
                    "JOIN building\n" +
                    "ON room.building_id = building.building_id\n";
        if (choose==0)
            SQL+= "order by class.class_id;";
        else if(choose == 1)
            SQL += "WHERE class_no = ? order by class.class_id;";
        else if(choose == 2)
            SQL += "WHERE course_id = ? order by class.class_id;";
        else if(choose == 3)
            SQL += "WHERE class.name LIKE ? order by class.class_id;";

        ArrayList<Course> courseList = new ArrayList<Course>();
        try
        {
            pstmt = conn.prepareStatement(SQL);
            if(choose!=0){
                pstmt.setString(1, searchWord);
                if(choose==3)
                    pstmt.setString(1, "%" + searchWord + "%");
            }

            rs = pstmt.executeQuery();

            while(rs.next())
            {
                Course course = new Course();
                course.setClassID(rs.getString(1));
                course.setClassNo(rs.getString(2));
                course.setClassCourseNo(rs.getString(3));
                course.setClassName(rs.getString(4));
                course.setClassLecturer(rs.getString(5));
                course.setClassStartTime(rs.getString(6));
                course.setClassEndTime(rs.getString(7));
                course.setClassPersonCurrent(rs.getString(8));
                course.setClassPersonMax(rs.getString(9));
                course.setClassRoomID(rs.getString(10));
                course.setClassBuildingName(rs.getString(11));
                courseList.add(course);
            }
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        return courseList;
    }

    public ArrayList<Course> showOLAP()
    {
        float avgScore = 0;
        ArrayList<Course> courseList = new ArrayList<Course>();

        String SQL ="SELECT Avg(number)FROM credits NATURAL JOIN intgrade;";
        try{
            pstmt = conn.prepareStatement(SQL);
            rs = pstmt.executeQuery();
            if(rs.next())
                avgScore = rs.getFloat(1);
        } catch (Exception e) {
            e.printStackTrace();
        }

        String SQL2 = "SELECT name, Avg(number) FROM course\n" +
                      "Natural JOIN credits natural join intgrade\n" +
                      "group by course_id ORDER BY ? - Avg(number) DESC limit 10;";

        try
        {
            pstmt = conn.prepareStatement(SQL2);
            pstmt.setFloat(1, avgScore);
            rs = pstmt.executeQuery();
            while(rs.next())
            {
                Course course = new Course();
                course.setClassName(rs.getString(1));
                course.setClassCredit(rs.getString(2));
                courseList.add(course);
            }
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        return courseList;
    }

    public ArrayList<Course> showSchedule(String studentID)
    {
        int begin = 0, end = 0;
        ArrayList<Course> tempList = new ArrayList<Course>();
        ArrayList<Course> courseList = new ArrayList<Course>();

        String SQL ="select name, begin, end from regist natural join class natural join time where student_id = ?;";
        try{
            pstmt = conn.prepareStatement(SQL);
            pstmt.setString(1,studentID);
            rs = pstmt.executeQuery();
            while(rs.next()){
                Course course = new Course();
                course.setClassName(rs.getString(1));
                course.setBeginTime(timeConvert(rs.getString(2)));
                course.setEndTime(timeConvert(rs.getString(3)));
                tempList.add(course);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        for(int i= 0; i< 36;i++){
            begin = i*30;
            end = begin +30;
            Course course = new Course();
            course.setClassMon("            ");
            course.setClassTue("            ");
            course.setClassWed("            ");
            course.setClassThu("            ");
            course.setClassFri("            ");
            for(int j=0; j<tempList.size();j++){
                if(tempList.get(j).getBeginTime()%1440>= begin
                && tempList.get(j).getBeginTime()%1440<  end
                || tempList.get(j).getEndTime()%1440  > begin
                && tempList.get(j).getEndTime()%1440  <=end
                || tempList.get(j).getBeginTime()%1440<= begin
                && tempList.get(j).getEndTime()%1440  >= end ) {
                    if (tempList.get(j).getBeginTime()/1440 == 0)
                        course.setClassMon(tempList.get(j).getClassName());
                    else if (tempList.get(j).getBeginTime()/1440 == 1)
                        course.setClassTue(tempList.get(j).getClassName());
                    else if (tempList.get(j).getBeginTime()/1440 == 2)
                        course.setClassWed(tempList.get(j).getClassName());
                    else if (tempList.get(j).getBeginTime()/1440 == 3)
                        course.setClassThu(tempList.get(j).getClassName());
                    else if (tempList.get(j).getBeginTime()/1440 == 4)
                        course.setClassFri(tempList.get(j).getClassName());
                }
            }
            courseList.add(course);
        }
        return courseList;
    }

    //수강신청
    public int registClass(Course course, String studentID, Boolean isRegit)
    {
        //결과 /  해당수업학점 / 해당 수업 현인원
        int result, credit = 0, person_current=-1;
        //해당 수업 과목 ID
        String courseID = "";
        //해당 학생 해당 수업 재수강 여부
        Boolean retake = false;
        //해당 수업 시작 시간
        ArrayList<Integer> timeBegin = new ArrayList<Integer>();
        //해당 수업 끝 시간
        ArrayList<Integer> timeEnd = new ArrayList<Integer>();

        //해당 수업 정원 확인
        String SQL0 = "SELECT person_max, person_current,credit, course_id,begin,end FROM class Natural join time WHERE class_id = ?;";
        try{
            pstmt =conn.prepareStatement(SQL0);
            pstmt.setString(1,course.getClassID());
            rs = pstmt.executeQuery();
            while(rs.next()){
                person_current = rs.getInt(2);
                if(rs.getInt(1) <= person_current)
                    return -2; //해당 수업 정원이 꽉참
                credit = rs.getInt(3);
                courseID = rs.getString(4);
                timeBegin.add(timeConvert(rs.getString(5)));
                timeEnd.add(timeConvert(rs.getString(6)));
            }
            if(person_current==-1)
                return -1; //해당 수업 존재하지 않음
        } catch (Exception e) {
            e.printStackTrace();
        }

        //해당 학생 18학점이상 신청 확인
        String SQL1;
        if(isRegit){
            SQL1 = "select SUM(credit) from class natural join regist where student_id = ?;";
        }
        else{
            SQL1 = "select SUM(credit) from class natural join hope where student_id = ?;";
        }
        try{
            pstmt =conn.prepareStatement(SQL1);
            pstmt.setString(1,studentID);
            rs = pstmt.executeQuery();
            if(rs.next()){
                if(credit+rs.getInt(1)>18)
                    return -3; //해당 학생 해당 수업 신청시 18학점 초과 됨
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        //해당 학생 재수강 여부 체크 및 B0이상 시 재수강 불가
        String SQL2 = "select number from course natural join credits natural join intgrade where course_id = ? and student_id = ?";
        try{
            pstmt =conn.prepareStatement(SQL2);
            pstmt.setString(1,courseID);
            pstmt.setString(2,studentID);
            rs = pstmt.executeQuery();
            if (rs.next()){
                retake = true;
                if(rs.getFloat(1)>=3.0)
                    return -4; //해당 학생 성적 B0이상, 재수강 불가
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        //해당 학생이 신청한 다른 수업과 해당 수업시간 겹침 여부 체킹
        String SQL3;
        if(isRegit){
            SQL3 = "select begin, end from class natural join regist natural join time where student_id = ? order by class_id;";
        }
        else{
            SQL3 = "select begin, end from class natural join hope natural join time where student_id = ? order by class_id;";
        }
        try{
            pstmt =conn.prepareStatement(SQL3);
            pstmt.setString(1,studentID);
            rs = pstmt.executeQuery();
            while (rs.next()){
                //timeBegin과 timeEnd가 해당 수업의 시작 시간과 끝 시간이다.
                for(int i=0; i<timeBegin.size();i++){
                    if(timeBegin.get(i) >= timeConvert(rs.getString(1))
                    && timeBegin.get(i) < timeConvert(rs.getString(2))
                    || timeEnd.get(i) > timeConvert(rs.getString(1))
                    && timeEnd.get(i) <= timeConvert(rs.getString(2)) )
                        return -5; //해당 수업 다른 수업과 시간대 겹침
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String SQL4;
        if(isRegit){
            SQL4 = "insert into regist(student_id, class_id) VALUES (?,?)";
        }
        else{
            SQL4 = "insert into hope(student_id, class_id) VALUES (?,?)";
        }
        try{

            pstmt = conn.prepareStatement(SQL4);
            pstmt.setString(1,studentID);
            pstmt.setString(2,course.getClassID());
            result = pstmt.executeUpdate();
            if(result == 0)
            {
                return -6; //insert 실패
            }
            if(!isRegit){
                return 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String SQL5 = "UPDATE class SET person_current = ? WHERE class_id = ?;";
        try{

            pstmt = conn.prepareStatement(SQL5);
            pstmt.setInt(1,person_current+1);
            pstmt.setString(2,course.getClassID());
            result = pstmt.executeUpdate();
            if(result == 0)
            {
                return -7; //update 실패
            }
            return 1; //insert 및 업데이트 성공
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -8; // 데이터베이스 오류
    }

    //신청 취소
    public int cancelClass(Course course, String studentID, Boolean isRegit)
    {
        //결과
        int result;
        int person_current = -1;

        String SQL0 = "SELECT person_current FROM class  WHERE class_id = ?;";
        try{
            pstmt =conn.prepareStatement(SQL0);
            pstmt.setString(1,course.getClassID());
            rs = pstmt.executeQuery();
            if(rs.next())
                person_current = rs.getInt(1);
            if(person_current == -1)
                return -1; //해당 수업 존재하지 않음
        } catch (Exception e) {
            e.printStackTrace();
        }

        String SQL1;
        if(isRegit){
            SQL1 = "DELETE FROM regist WHERE student_id=? and class_id=?";
        }
        else{
            SQL1 = "DELETE FROM hope WHERE student_id=? and class_id=?";
        }
        try{

            pstmt = conn.prepareStatement(SQL1);
            pstmt.setString(1,studentID);
            pstmt.setString(2,course.getClassID());
            result = pstmt.executeUpdate();
            if(result == 0)
            {
                return -2; //delete 실패
            }
            if(!isRegit){
                return 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String SQL2 = "UPDATE class SET person_current = ? WHERE class_id = ?;";
        try{

            pstmt = conn.prepareStatement(SQL2);
            pstmt.setInt(1,person_current-1);
            pstmt.setString(2,course.getClassID());
            result = pstmt.executeUpdate();
            if(result == 0)
            {
                return -3; //update 실패
            }
            return 1; //insert 및 update 성공
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -4; // 데이터베이스 오류
    }

}

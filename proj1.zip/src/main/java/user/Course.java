package user;

public class Course {

    private String ClassID;
    private String ClassNo;
    private String ClassCourseNo;
    private String ClassName;
    private String ClassMajorID;
    private String ClassYear;
    private String ClassCredit;
    private String ClassLecturer;
    private String ClassPersonMax;
    private String ClassOpened;
    private String ClassRoomID;
    private String ClassBuildingName;
    private String ClassPersonCurrent;
    private String ClassStartTime;
    private String ClassEndTime;
    private String ClassMon;
    private String ClassTue;
    private String ClassWed;
    private String ClassThu;
    private String ClassFri;
    private int beginTime;

    public int getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(int beginTime) {
        this.beginTime = beginTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    private int endTime;

    public String getClassID() {
        return ClassID;
    }

    public void setClassID(String classID) {
        ClassID = classID;
    }

    public String getClassNo() {
        return ClassNo;
    }

    public void setClassNo(String classNo) {
        ClassNo = classNo;
    }

    public String getClassCourseNo() {
        return ClassCourseNo;
    }

    public void setClassCourseNo(String classCourseNo) {
        ClassCourseNo = classCourseNo;
    }

    public String getClassName() {
        return ClassName;
    }

    public void setClassName(String className) {
        ClassName = className;
    }

    public String getClassMajorID() {
        return ClassMajorID;
    }

    public void setClassMajorID(String classMajorID) {
        ClassMajorID = classMajorID;
    }

    public String getClassYear() {
        return ClassYear;
    }

    public void setClassYear(String classYear) {
        ClassYear = classYear;
    }

    public String getClassCredit() {
        return ClassCredit;
    }

    public void setClassCredit(String classCredit) {
        ClassCredit = classCredit;
    }

    public String getClassLecturer() {
        return ClassLecturer;
    }

    public void setClassLecturer(String classLecturer) {
        ClassLecturer = classLecturer;
    }

    public String getClassPersonMax() {
        return ClassPersonMax;
    }

    public void setClassPersonMax(String classPersonMax) {
        ClassPersonMax = classPersonMax;
    }


    public String getClassOpened() {
        return ClassOpened;
    }

    public void setClassOpened(String classOpened) {
        ClassOpened = classOpened;
    }


    public String getClassRoomID() {
        return ClassRoomID;
    }

    public void setClassRoomID(String classRoomID) {
        ClassRoomID = classRoomID;
    }

    public String getClassBuildingName() {
        return ClassBuildingName;
    }

    public void setClassBuildingName(String classBuildingName) {
        ClassBuildingName = classBuildingName;
    }


    public String getClassPersonCurrent() {
        return ClassPersonCurrent;
    }

    public void setClassPersonCurrent(String classPersonCurrent) {
        ClassPersonCurrent = classPersonCurrent;
    }

    public String getClassStartTime() {
        return ClassStartTime;
    }

    public void setClassStartTime(String classStartTime) {
        ClassStartTime = classStartTime;
    }


    public String getClassEndTime() {
        return ClassEndTime;
    }

    public void setClassEndTime(String classEndTime) {
        ClassEndTime = classEndTime;
    }


    public String getClassThu() {
        return ClassThu;
    }

    public void setClassThu(String classThu) {
        ClassThu = classThu;
    }

    public String getClassWed() {
        return ClassWed;
    }

    public void setClassWed(String classWed) {
        ClassWed = classWed;
    }

    public String getClassTue() {
        return ClassTue;
    }

    public void setClassTue(String classTue) {
        ClassTue = classTue;
    }

    public String getClassMon() {
        return ClassMon;
    }

    public void setClassMon(String classMon) {
        ClassMon = classMon;
    }

    public String getClassFri() {
        return ClassFri;
    }

    public void setClassFri(String classFri) {
        ClassFri = classFri;
    }

}

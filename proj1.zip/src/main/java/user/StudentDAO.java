package user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class StudentDAO {


    private Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs;

    public StudentDAO()
    {
        try{
            //3306뒤에 bbs는 DB의 이름
            String dbURL = "jdbc:mysql://localhost:3306/db2018008204?serverTimezone=Asia/Seoul";
            String dbID = "root";
            String dbPassword = "sdijmkn7907";
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
        } catch (Exception e){
            e.printStackTrace();
        }
    }


    public int login(String studentID, String studentPassword)
    {
        String SQL = "SELECT password FROM student WHERE student_id = ?";
        try{

            pstmt = conn.prepareStatement(SQL);
            pstmt.setString(1, studentID);
            rs = pstmt.executeQuery();
            if(rs.next())
            {
                if(rs.getString(1).equals(studentPassword))
                {
                    return 1; //로그인 성공
                }
                else
                {
                    return 0; //비밀번호 불일치
                }
            }
            return -1; // 아이디가 없음
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -2; // 데이터베이스 오류
    }


    public ArrayList<String> showCredit(Student student)
    {
        String SQL1 = "SELECT year,grade,name,credit FROM credits NATURAL JOIN course WHERE student_id = ?";
        ArrayList<String> resultList = new ArrayList<String>();
        try
        {

            pstmt = conn.prepareStatement(SQL1);
            pstmt.setString(1,student.getStudentID());
            rs = pstmt.executeQuery();
            while(rs.next()){
                resultList.add(rs.getString(1) + "," +rs.getString(2) + "," +rs.getString(3)+","+rs.getString(4));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultList; //DB 오류
    }
    public String showLecturer(Student student)
    {
        String SQL = "SELECT lecturer_id FROM student WHERE student_id = ?";
        String SQL1 = "SELECT name FROM lecturer WHERE lecturer_id = ?";
        String student_id = "";
        try
        {
            pstmt = conn.prepareStatement(SQL);
            pstmt.setString(1, student.getStudentID());
            rs = pstmt.executeQuery();
            if(rs.next())
            {
                student_id = rs.getString(1);
            }
            else {
                return "-1";
            }
            pstmt = conn.prepareStatement(SQL1);
            pstmt.setString(1,student_id);
            rs = pstmt.executeQuery();
            if(rs.next()){
                return rs.getString(1);
            }
            return "-1"; // 아이디가 없음
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "-2"; //DB 오류
    }
    public int changeState(Student student)
    {
        String SQL = "UPDATE student SET state = ? WHERE student_id = ?";
        try
        {
            pstmt = conn.prepareStatement(SQL);
            pstmt.setString(1, student.getStudentState());
            pstmt.setString(2, student.getStudentID());
            return pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1; //DB 오류
    }


}
